<?php
require_once("../conexion/conexion.php");

$conexion = new Conexion();

// Consulta para la tabla "articulo"
$consultaArticulo = $conexion->query('SELECT * FROM articulo');
$dataArticulo = [];
while ($rowArticulo = $consultaArticulo->fetch(PDO::FETCH_ASSOC)) {
    $dataArticulo[] = $rowArticulo;
}

// Consulta para la tabla "contactenos"
$consultaContactenos = $conexion->query('SELECT * FROM contactenos');
$dataContactenos = [];
while ($rowContactenos = $consultaContactenos->fetch(PDO::FETCH_ASSOC)) {
    $dataContactenos[] = $rowContactenos;
}

// Consulta para la tabla "login"
$consultaLogin = $conexion->query('SELECT * FROM login');
$dataLogin = [];
while ($rowLogin = $consultaLogin->fetch(PDO::FETCH_ASSOC)) {
    $dataLogin[] = $rowLogin;
}

// Consulta para la tabla "registro"
$consultaRegistro = $conexion->query('SELECT * FROM registro');
$dataRegistro = [];
while ($rowRegistro = $consultaRegistro->fetch(PDO::FETCH_ASSOC)) {
    $dataRegistro[] = $rowRegistro;
}

// Consulta para la tabla "soporte"
$consultaSoporte = $conexion->query('SELECT * FROM soporte');
$dataSoporte = [];
while ($rowSoporte = $consultaSoporte->fetch(PDO::FETCH_ASSOC)) {
    $dataSoporte[] = $rowSoporte;
}

$response = [
    'articulo' => $dataArticulo,
    'contactenos' => $dataContactenos,
    'login' => $dataLogin,
    'registro' => $dataRegistro,
    'soporte' => $dataSoporte
];

header('Content-Type: application/json');
echo json_encode($response);

$conexion = null;
?>
