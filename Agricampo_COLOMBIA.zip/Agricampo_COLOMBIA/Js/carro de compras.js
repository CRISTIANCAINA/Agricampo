document.addEventListener("DOMContentLoaded", function () {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    const selectedItemsInput = document.getElementById('productos-hidden'); // Cambia el ID para que coincida con el campo oculto en el formulario
    let cartCount = 0;
    let totalCost = 0;
    const selectedItems = [];

    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            const product = button.parentElement;
            const productName = product.querySelector('h2').textContent;
            const productPrice = parseFloat(product.querySelector('.price').textContent);

            // Crear objeto para el producto
            const productObj = {
                name: productName,
                price: productPrice
            };

            // Agregar el producto seleccionado al array
            selectedItems.push(productObj);

            // Crear elemento de lista para el carrito
            const cartItem = document.createElement('li');
            cartItem.textContent = `${productName} - $${productPrice.toFixed(2)}`;
            cartItems.appendChild(cartItem);

            // Actualizar el contador y el total
            cartCount++;
            totalCost += productPrice;

            updateCart();
        });
    });

    function updateCart() {
        document.getElementById('cart-count').textContent = cartCount;
        cartTotal.textContent = `$${totalCost.toFixed(2)}`;

        // Actualizar el input oculto con los productos seleccionados
        selectedItemsInput.value = JSON.stringify(selectedItems);
    }

    // Cuando el usuario hace clic en "PAGAR"
    document.querySelector("form").addEventListener("submit", function (e) {
        e.preventDefault();

        // Envía el formulario con los productos seleccionados
        this.submit();
    });
});
