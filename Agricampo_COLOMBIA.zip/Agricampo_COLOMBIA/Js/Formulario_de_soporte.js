document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("solicitud-form");
    const mensaje = document.getElementById("mensaje");
    formulario.addEventListener("submit", function (e) {
        e.preventDefault();
        // Simulación de envío de solicitud 
        setTimeout(function () {
            mensaje.style.display = "block";
            formulario.reset();
        }, 2000);
        // El mensaje se mostrará después de 2 segundos (2000 milisegundos).
    });
});