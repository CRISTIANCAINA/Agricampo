// Define data table options
const dataTableOptions = {};

// Initialize data table
const initDataTable = async () => {
    if (dataTableIsInitialized) {
        dataTable.destroy();
    }

    await listUsers();

    dataTable = $("#datatable_users").DataTable(dataTableOptions);

    dataTableIsInitialized = true;
};

// List users
const listUsers = async () => {
    try {
        const response = await fetch("../Datos/Datos1.php");
        const users = await response.json();

        let content = ``;
        users.forEach((user, index) => {
            content += `
                <tr>
                    <td>${user.id}</td>
                    <td>${user.nombre}</td>
                    <td>${user.usuario}</td>
                    <td>${user.email}</td>
                    <td>${user.password}</td>
                </tr>`;
        });
        tableBody_users.innerHTML = content;
    } catch (ex) {
        alert(ex);
    }
};
