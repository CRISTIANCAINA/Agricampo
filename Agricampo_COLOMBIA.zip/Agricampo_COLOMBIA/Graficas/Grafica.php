<?php
require_once("../conexion/conexion.php");

$conexion = new Conexion();

// Consulta a la primera tabla
$consulta_tabla1 = $conexion->query('SELECT * FROM registro');
$data_tabla1 = [];

while ($row = $consulta_tabla1->fetch(PDO::FETCH_ASSOC)) {
    $data_tabla1[] = $row;
}

// Consulta a la segunda tabla
$consulta_tabla2 = $conexion->query('SELECT * FROM soporte');
$data_tabla2 = [];

while ($row = $consulta_tabla2->fetch(PDO::FETCH_ASSOC)) {
    $data_tabla2[] = $row;
}
// Consulta a la tercera tabla
$consulta_tabla3 = $conexion->query('SELECT * FROM login');
$data_tabla3 = [];

while ($row = $consulta_tabla3->fetch(PDO::FETCH_ASSOC)) {
    $data_tabla3[] = $row;
}
// Consulta a la cuarta tabla
$consulta_tabla4 = $conexion->query('SELECT * FROM contactenos');
$data_tabla4 = [];

while ($row = $consulta_tabla4->fetch(PDO::FETCH_ASSOC)) {
    $data_tabla4[] = $row;
}
// Consulta a la cuarta tabla
$consulta_tabla5 = $conexion->query('SELECT * FROM articulo');
$data_tabla5 = [];

while ($row = $consulta_tabla5->fetch(PDO::FETCH_ASSOC)) {
    $data_tabla5[] = $row;
}
$response = [
    'data_tabla1' => $data_tabla1,
    'data_tabla2' => $data_tabla2,
    'data_tabla3' => $data_tabla3,
    'data_tabla4' => $data_tabla4,
    'data_tabla5' => $data_tabla5
];

header('Content-Type: application/json');

echo json_encode($response);

$conexion = null;
?>
