<?php
require_once ("conDB.php");
class UserModel{

    static public function createUser($data){
        $cantMail = self::getMail($data['use_mail']);
        if($cantMail==0){
            $query="INSERT INTO users(use_id,use_mail,use_pss,use_dateCreate,us_identifier,us_key,us_status) 
            VALUES (NULL,:use_mail,:use_pss,:use_dateCreate,:us_identifier,:us_key,:us_status)";
           
            $status="0";// 0->inactivo , 1-> activo
            $stament = Connection::connecction()->prepare($query);
            $stament-> bindParam(":use_mail",$data["use_mail"],PDO::PARAM_STR);
            $stament-> bindParam(":use_pss",$data["use_pss"],PDO::PARAM_STR);
            $stament-> bindParam(":use_dateCreate",$data["use_dateCreate"],PDO::PARAM_STR);
            $stament-> bindParam(":us_identifier",$data["ue_identifier"],PDO::PARAM_STR);
            $stament-> bindParam(":us_key",$data["us_key"],PDO::PARAM_STR);
            $stament-> bindParam(":us_status",$status,PDO::PARAM_STR);
            $message= $stament->execute() ? "ok" : Connection::connecction()->errorInfo();
            $stament-> closeCursor();
         
            $stament = null;
            $query = "";
        }else{
            $message = "Usuario ya esta registrado";
        }
        return $message;

    }
    static private function getMail($mail){
        $query= "SELECT use_mail FROM users WHERE use_mail = '$mail' ";
        $stament = Connection::connecction()->prepare($query);
        $stament->execute(); 
        $result=$stament->rowCount();
        return $result; 
    }

    static  function getUsers($parametro){  //Funcion que trae todos lo usuario
        $param = is_numeric($parametro) ? $parametro : 0;
        $query = "SELECT use_id, use_mail, use_dateCreate FROM users";
        $query.= ($param > 0) ? " WHERE users.use_id = '$param' AND  " : "";
        $query.= ($param > 0) ? " us_status = '1' " : " WHERE us_status= '1';";
        //echo $query;
        $stament = Connection::connecction()->prepare($query);
        $stament->execute(); 
        $result=$stament->fetchAll(PDO::FETCH_ASSOC); //Mandar todos los registros asociados a la ejecucion
        return $result; 
    }
    //Login
    static public function login($data){
        //$query="";
        $user = $data['use_mail'];
        $pass = md5($data['use_pass']);
        // echo $pass;
        if (!empty($user) && !empty($pass)){
            $query = "SELECT us_key, use_paramentifier, use_param FROM users WHERE use_mail = '$user' 
            and use_pps= '$pass' and us_status = '1' ";
            $stament = Connection::connecction()->prepare($query);
            $stament->execute(); 
            $result=$stament->fetchAll(PDO::FETCH_ASSOC);
            return $result; 
        }else{
            return "Error en Crendenciales";
        }
    }
    static public function getUserAuth(){
        $query="";
        $query = "SELECT us_identifier, us_key FROM users WHERE us_status = '1' ; ";
        //echo $query;
        $stament = Connection::connecction()->prepare($query);
        $stament->execute(); 
        $result=$stament->fetchAll(PDO::FETCH_ASSOC);
        return $result; 
    }
}

?>