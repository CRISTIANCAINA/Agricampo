<?php
require_once '../conexion/conexion.php';
class servicio_de_soporte {
    private $id;
    private $nombre;
    private $correo;
    private $Mensaje;

    const TABLA = 'soporte';

    public function __construct($nombre, $correo, $Mensaje, $id = null){
        
            $this->id = $id;
            $this->nombre = $nombre;
            $this->correo = $correo;
            $this->Mensaje = $Mensaje;
        
    }
    public function getid(){ 
        return $this->id; 
    }
    public function getnombre(){ 
        return $this->nombre; 
    }

    public function getcorreo(){ 
        return $this->correo; 
    }
    public function getMensaje(){ 
        return $this->Mensaje; 
    }
    public function setid(){ 
        return $this->id; 
    }

    public function setnombre(){ 
        return $this->nombre; 
    }

    public function setcorreo(){ 
        return $this->correo; 
    }
    public function setMensaje(){ 
        return $this->Mensaje; 
    }

    public function guardar(){

        $conexion = new Conexion();
  
  {
  
           $consulta = $conexion->prepare('INSERT INTO ' . self::TABLA .' (nombre, correo, Mensaje) VALUES(:nombre, :correo, :Mensaje)');

           $consulta->bindParam(':nombre', $this->nombre);
  
           $consulta->bindParam(':correo', $this->correo);
  
           $consulta->bindParam(':Mensaje', $this->Mensaje);
  
           $consulta->execute();
  
           $this->id = $conexion->lastInsertid();
  
        }
        
  
        $conexion = null;
  
     }

    
    
   
}


?>