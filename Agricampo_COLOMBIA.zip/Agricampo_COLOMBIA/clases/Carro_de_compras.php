clase: <?php

class Compras {

  private $id;

  private $productos;

  private $Total;



  const TABLA = 'Compras';

 

  public function getId() {

      return $this->id;

  }

 

  public function getproductos() {

      return $this->productos;

  }

 

  public function getTotal() {

      return $this->Total;

  }

 



 

  public function setId($id) {

      $this->id = $id;

  }

 

  public function setproductos($productos) {

      $this->productos = $productos;

  }

 

  public function setTotal($Total) {

      $this->Total = $Total;

  }

 



 

  public function __construct($productos, $Total, $id=null) {

      $this->id = $id;

      $this->productos = $productos;

      $this->Total = $Total;



  }

  public function guardar(){

    $conexion = new Conexion();

{
       $consulta = $conexion->prepare('INSERT INTO ' . self::TABLA .' (id, productos, Total) VALUES(:id, :producto, :Total)');

       $consulta->bindParam(':id', $this->id);
       $consulta->bindParam(':productos', $this->productos);
       $consulta->bindParam(':Total', $this->Total);
       $consulta->execute();
       $this->id = $conexion->lastInsertId();
    }
    $conexion = null;

}
}
?>