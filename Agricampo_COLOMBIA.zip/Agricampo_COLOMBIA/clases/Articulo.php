<?php
require_once '../conexion/conexion.php';
class Articulo {
    private $id;
    private $nombre;
    private $price; 
    private $affair; 
    private $Mensaje; 
    const TABLA = 'articulo';

    public function getId() {
        return $this->id;
    }
    public function getnombre(){ 
      return $this->nombre; 
    }
    public function getprice(){ 
        return $this->price; 
    }

    public function getaffair(){ 
        return $this->affair; 
    }
    public function getMensaje(){ 
      return $this->Mensaje; 
  }
    public function setid($id) {

        $this->id = $id;
  
    }
    public function setnombre($nombre) {

        $this->nombre = $nombre;
  
    }
    public function setprice($price) {

        $this->price = $price;
  
    }
    public function setaffair($affair) {

        $this->affair = $affair;
  
    }
    public function setMensaje($Mensaje) {

      $this->Mensaje = $Mensaje;

  }
    public function __construct($nombre,$price, $affair, $Mensaje, $id=null) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->price = $price; 
        $this->affair = $affair; 
        $this->Mensaje = $Mensaje; 

    }
    public function guardar(){

        $conexion = new Conexion();
  
  {
  
           $consulta = $conexion->prepare('INSERT INTO ' . self::TABLA .' (id, nombre, price, affair, Mensaje) VALUES(:id, :nombre, :price, :affair, :Mensaje)');
  
           $consulta->bindParam(':id', $this->id);
           $consulta->bindParam(':nombre', $this->nombre);
           $consulta->bindParam(':price', $this->price);
           $consulta->bindParam(':affair', $this->affair);
           $consulta->bindParam(':Mensaje', $this->Mensaje);
           $consulta->execute();
           $this->id = $conexion->lastInsertId();
  
        }
  
        $conexion = null;
    }
};
?>