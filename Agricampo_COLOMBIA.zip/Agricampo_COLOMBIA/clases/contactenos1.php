<?php
require_once '../conexion/conexion.php';
class contactenos {
    private $id;
    private $nombre;
    private $correo;
    private $celular;
    private $mensaje;

    const TABLA = 'contactenos';
    
    public function __construct($nombre, $correo, $celular,$mensaje,$id = null){

            $this->id = $id;
            $this->nombre = $nombre;
            $this->correo = $correo;
            $this->celular = $celular;
            $this->mensaje = $mensaje;
           
        
    }
    public function getid(){ 
        return $this->id; 
    }
    public function getnombre(){ 
        return $this->nombre; 
    }

    public function getcorreo(){ 
        return $this->correo; 
    }
    public function getcelular(){ 
        return $this->celular; 
    }
    public function getmensaje(){ 
        return $this->mensaje; 
    }
    public function setid($id){ 
         $this->id = $id; 
    }
    public function setnombre($nombre){ 
         $this->nombre = $nombre; 
    }

    public function setcorreo($correo){ 
         $this->correo = $correo; 
    }
    public function setcelular($celular){ 
         $this->celular = $celular; 
    }
    public function setmensaje($mensaje){ 
         $this->mensaje = $mensaje; 
    }
    public function guardar(){

        $conexion = new Conexion();
  
  {
  
    $consulta = $conexion->prepare('INSERT INTO ' . self::TABLA .' (nombre,correo, celular, mensaje) VALUES(:nombre,:correo, :celular,:mensaje)');

    $consulta->bindParam(':nombre', $this->nombre);

    $consulta->bindParam(':correo', $this->correo);

    $consulta->bindParam(':celular', $this->celular);

    $consulta->bindParam(':mensaje', $this->mensaje);

    $consulta->execute();

    $this->id = $conexion->lastInsertid();

 }
 
        
  
        $conexion = null;
  
     }    
    
   
}


?>