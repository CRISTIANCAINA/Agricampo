<?php

require_once '../conexion/conexion.php';

class Registrarse {

    private $id;

    private $nombre;

    private $email;

    private $usuario;

    private $password;

    const TABLA = 'registro';

 

    public function getId() {

        return $this->id;

    }

    public function getNombre(){

      return $this->nombre;

    }

    public function getEmail(){

        return $this->email;

    }

    public function getUsuario(){

        return $this->usuario;

    }

 

    public function getPassword(){

        return $this->password;

    }

    

    public function setNombre($nombre) {

 

        $this->nombre = $nombre;

 

    }

    public function setEmail($email) {

 

        $this->email = $email;

 

    }

    public function setUsuario($usuario) {

 

        $this->usuario = $usuario;

 

    }

    public function setPassword($password) {

 

        $this->password = $password;

 

    }

    public function __construct($nombre, $email, $usuario, $password, $id=null) {

        $this->id = $id;

        $this->nombre = $nombre;

        $this->email = $email;

        $this->usuario = $usuario;

        $this->password = $password;

 

    }

    public function guardar(){

        $conexion = new Conexion();

  {

           $consulta = $conexion->prepare('INSERT INTO ' . self::TABLA .' (nombre, email, usuario, password) VALUES(:nombre, :email, :usuario, :password)');



           $consulta->bindParam(':nombre', $this->nombre);

           $consulta->bindParam(':email', $this->email);

           $consulta->bindParam(':usuario', $this->usuario);

           $consulta->bindParam(':password', $this->password);

           $consulta->execute();

           

           $this->id = $conexion->lastInsertId();

 

        }

 

        $conexion = null;

 

    }
    public static function recuperarTodos(){

        $conexion = new Conexion();
 
        $consulta = $conexion->prepare('SELECT id, nombre, email, usuario, password FROM ' . self::TABLA . ' ORDER BY nombre');
 
        $consulta->execute();
 
        $registros = $consulta->fetchAll();
 
        return $registros;
 
     }

}

?>


