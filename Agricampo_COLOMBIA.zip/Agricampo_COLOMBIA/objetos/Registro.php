<?php
require_once("../clases/Registro.php");
$objEmployee = new Registrarse ($_POST['nombre'], $_POST['email'], $_POST['usuario'], $_POST['password']);
$objEmployee->guardar();
header('Location: ../Login.html');
exit;

?>