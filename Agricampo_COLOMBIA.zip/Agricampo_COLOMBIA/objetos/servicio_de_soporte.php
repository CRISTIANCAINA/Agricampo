<?php
require_once("../clases/servicio_de_soporte.php");
$objEmployee = new servicio_de_soporte ($_POST['nombre'], $_POST['correo'], $_POST['Mensaje']);
$objEmployee->guardar();
header('Location: ../index.html');
exit; 

?>