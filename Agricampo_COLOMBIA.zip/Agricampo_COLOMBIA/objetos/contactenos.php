<?php
require_once("../clases/contactenos1.php");
$objEmployee = new contactenos ($_POST['nombre'], $_POST['correo'], $_POST['celular'], $_POST['mensaje']);
$objEmployee->guardar(); 
header('Location: ../index.html');
exit;

?>