<?php
require_once("../clases/Carro_de_compras.php");

if (isset($_POST['Productos']) && isset($_POST['Total'])) {
    $productos = json_decode($_POST['Productos']); // Decodificar el JSON enviado desde JavaScript
    $total = $_POST['Total'];

    $objEmployee = new Compras($productos, $total);
    $objEmployee->guardar();
    echo "Los datos se han guardado correctamente.";
} else {
    echo "Faltan datos necesarios para guardar la compra.";
}

?>