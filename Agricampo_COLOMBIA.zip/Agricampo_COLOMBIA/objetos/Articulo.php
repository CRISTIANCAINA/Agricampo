<?php
require_once("../clases/Articulo.php");
$objEmployee = new Articulo ($_POST['nombre'], $_POST['price'], $_POST['affair'], $_POST['Mensaje']);
$objEmployee->guardar();
header('Location: ../index.html');
exit;
?>