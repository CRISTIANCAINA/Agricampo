<?php
require_once("../clases/Usuario.php");

// Verificar si se enviaron datos por POST
if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

  
    $objEmployee = new Usuario($email, $password);


    if ($objEmployee->validarusuario()) {

        $objEmployee->guardar();


        header('Location: ../index.html');
        exit;
    } else {
        header('Location: ../Login.html');
        exit;
    }
}
?>

